delete(gcp('nocreate'));     % 确保没有并行池运行        
parpool('local', 12);
matrix_ising = h5read('matrix_ising_conformity_1_川崎病(20210730).h5', '/Ising');
matrix_ising = matrix_ising'; 
[m,n] = size(matrix_ising);
colum= n    ; 
rho=0.1;             % the regularization parameter
                     % it is a ratio between (0,1), if .rFlag=1
z=40;
opts=[]; 
 
% Starting point
opts.init=2   ;        % starting from a zero point 
 
% Termination 
opts.tFlag=5;       % run .maxIter iterations 
opts.maxIter=100;    % maximum number of iterations         

% Normalization
opts.nFlag=0;       % without normalization
              
% Regularization 
opts.rFlag=1;       % the input parameter 'rho' is a ratio in (0, 1) 
%opts.rsL2=0.01;     % the squared two norm term 

% Group Property
opts.sWeight=[1,1]; % set the weight for positive and neg ative samples

fprintf('\n mFlag=0, lFlag=0 \n');
opts.mFlag=0;       % treating it as compositive function 
opts.lFlag=0;       % Nemirovski's line search
tic;
data_use =matrix_ising;
result_use = ones(colum,colum);
y=matrix_ising(:,1);
data_use(:,1)=[];
parfor i=1:colum
    data_use = matrix_ising;
    y=matrix_ising(:,i);
    [x, c, funVal, ValueL]= LogisticC(data_use, y, z, opts);
    result_use(:,i)=x;
end

toc; 